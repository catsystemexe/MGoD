import { Config } from "../core/Config";

export class HUD {
  constructor() {}

  render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    energy: number,
    maxEnergy: number,
    score: number,
    waveInfo: string,
    snakeLen: number,
    wStatus: { 
        w2Ready: boolean; w2Cd: number; w2MaxCd: number; 
        bombReady: boolean; bombCd: number; bombMaxCd: number;
        lvlW1: number; lvlW2: number 
    }
  ) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    const padding = 30; // Větší odsazení od krajů

    // --- 1. SKÓRE (Nahoře Uprostřed - Největší) ---
    this.drawScore(ctx, width / 2, padding + 10, score);

    // --- 2. WAVE INFO (Pod skóre) ---
    this.drawWaveInfo(ctx, width / 2, padding + 45, waveInfo);

    // --- 3. ENERGY BAR (Vlevo dole) ---
    this.drawEnergyBar(ctx, padding, height - padding - 10, energy, maxEnergy);

    // --- 4. ZBRANĚ (Vpravo dole) ---
    this.drawWeapons(ctx, width - padding, height - padding - 10, wStatus, snakeLen);

    ctx.restore();
  }

  private drawEnergyBar(ctx: CanvasRenderingContext2D, x: number, y: number, current: number, max: number) {
    const w = 220;
    const h = 20; // Tlustší bar
    const pct = Math.max(0, current / max);

    // Label
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 14px monospace";
    ctx.textAlign = "left";
    ctx.shadowBlur = 0;
    ctx.fillText(`ENERGY`, x, y - 8);

    // Pozadí
    ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
    ctx.fillRect(x, y, w, h);

    // Rámeček
    ctx.strokeStyle = "#555555";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);

    // Výplň
    let color = "#00FF00";
    if (pct < 0.5) color = "#FFFF00";
    if (pct < 0.25) color = "#FF0000";

    if (pct > 0) {
        ctx.fillStyle = color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = color;
        ctx.fillRect(x + 2, y + 2, (w - 4) * pct, h - 4);
        ctx.shadowBlur = 0;
    }
  }

  private drawWeapons(ctx: CanvasRenderingContext2D, rightX: number, bottomY: number, status: any, snakeLen: number) {
      const boxSize = 60; // Větší ikonky
      const gap = 15;

      // Kreslíme zprava doleva

      // 3. Bomb (Space) - Úplně vpravo
      const bombPct = status.bombReady ? 1.0 : 1.0 - (status.bombCd / status.bombMaxCd);
      const canAfford = snakeLen > 1;
      const bombColor = canAfford ? "#FF0000" : "#555555";
      this.drawWeaponBox(ctx, rightX - boxSize, bottomY - boxSize, boxSize, 
          "SPC", `x${Math.max(0, snakeLen - 1)}`, bombPct, bombColor);

      // 2. Shotgun (RMB)
      const shotgunPct = status.w2Ready ? 1.0 : 1.0 - (status.w2Cd / status.w2MaxCd);
      this.drawWeaponBox(ctx, rightX - boxSize * 2 - gap, bottomY - boxSize, boxSize, 
          "RMB", `Lvl ${status.lvlW2}`, shotgunPct, "#FF8800");

      // 1. MG (LMB)
      this.drawWeaponBox(ctx, rightX - boxSize * 3 - gap * 2, bottomY - boxSize, boxSize, 
          "LMB", `Lvl ${status.lvlW1}`, 1.0, "#00FFFF");
  }

  private drawWeaponBox(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, label: string, sub: string, pct: number, color: string) {
      // Background
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      ctx.fillRect(x, y, s, s);

      // Cooldown Fill
      if (pct > 0) {
          ctx.fillStyle = color;
          ctx.globalAlpha = 0.4; // Průhledná výplň
          const h = s * pct;
          ctx.fillRect(x, y + (s - h), s, h);
          ctx.globalAlpha = 1.0;
      }

      // Border (Active/Inactive)
      if (pct >= 1.0) {
          ctx.strokeStyle = color;
          ctx.shadowBlur = 10;
          ctx.shadowColor = color;
          ctx.lineWidth = 2;
      } else {
          ctx.strokeStyle = "#444444";
          ctx.shadowBlur = 0;
          ctx.lineWidth = 1;
      }
      ctx.strokeRect(x, y, s, s);
      ctx.shadowBlur = 0;

      // Text
      ctx.fillStyle = "#FFFFFF";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      // Label (LMB/RMB)
      ctx.font = "bold 14px monospace";
      ctx.fillText(label, x + s/2, y + 15);

      // Sub (Level)
      ctx.font = "11px monospace";
      ctx.fillStyle = "#CCCCCC";
      ctx.fillText(sub, x + s/2, y + s - 12);
  }

  private drawScore(ctx: CanvasRenderingContext2D, centerX: number, y: number, score: number) {
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 32px monospace"; // Větší font
      ctx.textAlign = "center"; // Zarovnání na střed
      ctx.textBaseline = "top";

      ctx.shadowBlur = 15;
      ctx.shadowColor = "#FFFFFF";

      const scoreStr = score.toString().padStart(6, "0");
      ctx.fillText(scoreStr, centerX, y);

      ctx.shadowBlur = 0;
      ctx.font = "12px monospace";
      ctx.fillStyle = "#AAAAAA";
      ctx.fillText("SCORE", centerX, y - 14);
  }

  private drawWaveInfo(ctx: CanvasRenderingContext2D, centerX: number, y: number, info: string) {
      ctx.fillStyle = "#00FFCC";
      ctx.font = "bold 16px monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "top";

      ctx.shadowBlur = 10;
      ctx.shadowColor = "#00FFCC";

      ctx.fillText(info, centerX, y);
      ctx.shadowBlur = 0;
  }
}
