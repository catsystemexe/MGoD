import { Vec2, v2, lerp } from "../utils/math";
import { Config } from "../core/Config";

export class Camera {
  private pos: Vec2 = v2(0, 0);
  
  // Shake params
  private trauma = 0; // 0.0 až 1.0 (úroveň stresu kamery)
  private shakeOffset = v2(0, 0);

  constructor() {}

  // Přidat "trauma" (sílu otřesu). Např. 0.5 pro zásah, 1.0 pro bombu.
  addShake(amount: number) {
    this.trauma = Math.min(1.0, this.trauma + amount);
  }

  update(dt: number) {
    // Trauma klesá lineárně
    this.trauma = Math.max(0, this.trauma - dt * 2.0); // 2.0 = jak rychle se uklidní

    // Výpočet offsetu: Shake = Trauma^2 * MaxShake
    // Umocnění na druhou dělá přechod plynulejším
    const shakeAmount = this.trauma * this.trauma * 15; // 15px max výchylka
    
    // Náhodný jitter
    const angle = Math.random() * Math.PI * 2;
    this.shakeOffset.x = Math.cos(angle) * shakeAmount;
    this.shakeOffset.y = Math.sin(angle) * shakeAmount;
  }

  follow(prev: Vec2, cur: Vec2, alpha: number): Vec2 {
    // Interpolace pozice hráče
    const tx = lerp(prev.x, cur.x, alpha);
    const ty = lerp(prev.y, cur.y, alpha);
    
    // Smooth follow (tlumení)
    this.pos.x += (tx - this.pos.x) * 0.1;
    this.pos.y += (ty - this.pos.y) * 0.1;

    // Aplikace Shake offsetu do finální pozice
    return { 
        x: this.pos.x + this.shakeOffset.x, 
        y: this.pos.y + this.shakeOffset.y 
    };
  }
}
